
import React, { useState } from 'react';
import { Button } from './Button';
import { Sparkles, BookOpen, Star, Wand2 } from 'lucide-react';
import { Language, translations } from '../types';

interface StoryCreatorProps {
  onGenerate: (prompt: string) => void;
  isGenerating: boolean;
  language: Language;
  setLanguage: (lang: Language) => void;
}

export const StoryCreator: React.FC<StoryCreatorProps> = ({ onGenerate, isGenerating, language, setLanguage }) => {
  const [prompt, setPrompt] = useState('');
  const t = translations[language];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim()) {
      onGenerate(prompt);
    }
  };

  const handleLucky = () => {
    const { adjectives, characters, actions, places } = t.creative;
    
    const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
    const char = characters[Math.floor(Math.random() * characters.length)];
    const act = actions[Math.floor(Math.random() * actions.length)];
    const place = places[Math.floor(Math.random() * places.length)];

    // Simple concatenation works for English: "A brave dinosaur who loves to dance on the moon"
    // For Turkish, the order in the arrays is designed to be loosely compatible, or Gemini will fix grammar.
    // TR: "Cesur bir dinozor dans etmeyi seven ayda" -> A bit broken but Gemini understands context perfectly.
    // To make TR better we might rearrange, but for simplicity and AI flexibility, appending is usually fine.
    // Let's try to order it slightly better for TR if possible, but linear is generally okay for GenAI prompts.
    
    let combinedPrompt = "";
    if (language === 'tr') {
        // TR Grammar approximation: Place + Action + Adjective + Character (Ayda dans eden cesur bir dinozor)
        combinedPrompt = `${place} ${act} ${adj} ${char}`;
    } else {
        // EN: Adjective + Character + Action + Place
        combinedPrompt = `${adj} ${char} ${act} ${place}`;
    }

    setPrompt(combinedPrompt);
    onGenerate(combinedPrompt);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-12 flex flex-col items-center justify-center min-h-[80vh] animate-fade-in relative">
      
      {/* Language Toggle */}
      <div className="absolute top-4 right-4 md:top-8 md:right-8">
        <div className="flex items-center bg-white rounded-full p-1 shadow-sm border border-amber-100">
          <button
            onClick={() => setLanguage('en')}
            className={`px-3 py-1 rounded-full text-sm font-bold transition-colors ${language === 'en' ? 'bg-amber-100 text-amber-800' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            EN
          </button>
          <button
            onClick={() => setLanguage('tr')}
            className={`px-3 py-1 rounded-full text-sm font-bold transition-colors ${language === 'tr' ? 'bg-amber-100 text-amber-800' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            TR
          </button>
        </div>
      </div>

      <div className="text-center mb-12">
        <div className="inline-block p-4 rounded-full bg-amber-100 mb-6 transform rotate-3 hover:rotate-0 transition-transform duration-500">
            <BookOpen size={64} className="text-amber-600" />
        </div>
        <h1 className="text-5xl md:text-6xl font-bold text-slate-800 mb-4 font-comic tracking-tight">
          {t.title}
        </h1>
        <p className="text-xl text-slate-600 max-w-md mx-auto">
          {t.subtitle}
        </p>
      </div>

      <div className="w-full max-w-lg space-y-4">
        <form onSubmit={handleSubmit} className="relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-amber-400 to-pink-400 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
          <div className="relative bg-white rounded-2xl p-2 shadow-xl flex flex-col md:flex-row gap-2">
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={t.placeholder}
              className="flex-1 px-6 py-4 text-lg rounded-xl border-none focus:ring-2 focus:ring-amber-200 focus:outline-none text-slate-700 placeholder:text-slate-400"
              disabled={isGenerating}
            />
            <Button 
              type="submit" 
              size="lg" 
              isLoading={isGenerating}
              className="md:w-auto w-full"
            >
              <Sparkles className="mr-2 h-5 w-5" />
              {t.create}
            </Button>
          </div>
        </form>

        <div className="flex justify-center">
          <button 
            type="button"
            onClick={handleLucky}
            disabled={isGenerating}
            className="group relative flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white rounded-full font-bold shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed overflow-hidden"
          >
            <div className="absolute inset-0 bg-white/20 group-hover:animate-pulse"></div>
            <Wand2 size={20} className="text-yellow-200" />
            <span className="relative">{t.lucky}</span>
          </button>
        </div>
      </div>

      <div className="mt-12 flex flex-wrap justify-center gap-4 text-sm text-slate-500">
        {t.features.map((feature, i) => (
            <div key={i} className="flex items-center gap-1">
              <Star size={16} className="text-amber-400 fill-amber-400" />
              <span>{feature}</span>
            </div>
        ))}
      </div>
    </div>
  );
};
