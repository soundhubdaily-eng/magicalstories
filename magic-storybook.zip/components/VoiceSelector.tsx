
import React from 'react';
import { Language, translations } from '../types';
import { User, UserCheck, Smile } from 'lucide-react';

interface VoiceSelectorProps {
  language: Language;
  onSelect: (voice: string) => void;
}

export const VoiceSelector: React.FC<VoiceSelectorProps> = ({ language, onSelect }) => {
  const t = translations[language];

  const voices = [
    { id: 'Puck', label: t.voices.boy, icon: <Smile size={48} />, color: 'bg-blue-100 text-blue-600 hover:bg-blue-200 border-blue-300' },
    { id: 'Kore', label: t.voices.girl, icon: <Smile size={48} />, color: 'bg-pink-100 text-pink-600 hover:bg-pink-200 border-pink-300' },
    { id: 'Zephyr', label: t.voices.woman, icon: <User size={48} />, color: 'bg-purple-100 text-purple-600 hover:bg-purple-200 border-purple-300' },
    { id: 'Fenrir', label: t.voices.man, icon: <UserCheck size={48} />, color: 'bg-emerald-100 text-emerald-600 hover:bg-emerald-200 border-emerald-300' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-4xl w-full animate-bounce-in">
        <div className="text-center mb-8">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-800 font-comic mb-2">
            {t.selectVoiceTitle}
          </h2>
          <p className="text-slate-500 text-lg">
            {t.selectVoiceSubtitle}
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {voices.map((voice) => (
            <button
              key={voice.id}
              onClick={() => onSelect(voice.id)}
              className={`
                flex flex-col items-center justify-center p-6 rounded-2xl border-b-4 transition-all active:border-b-0 active:translate-y-1
                ${voice.color}
              `}
            >
              <div className="mb-4 bg-white/50 p-4 rounded-full">
                {voice.icon}
              </div>
              <span className="text-xl font-bold">{voice.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
