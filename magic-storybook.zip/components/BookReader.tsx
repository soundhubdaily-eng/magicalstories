
import React, { useEffect, useRef, useState } from 'react';
import { Story, StoryPage, translations } from '../types';
import { generateIllustration, generatePageAudio } from '../services/geminiService';
import { Button } from './Button';
import { ArrowLeft, ArrowRight, RefreshCw, Home, MessageCircle, PlayCircle, CirclePause, Settings, ChevronUp, Volume2, Gauge, Check } from 'lucide-react';
import { User, UserCheck, Smile } from 'lucide-react'; // Icons for avatars

interface BookReaderProps {
  story: Story;
  initialVoice: string;
  onExit: () => void;
  onOpenChat: () => void;
}

export const BookReader: React.FC<BookReaderProps> = ({ story, initialVoice, onExit, onOpenChat }) => {
  const [currentPageIndex, setCurrentPageIndex] = useState(0);
  const [pages, setPages] = useState<StoryPage[]>(story.pages);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  const [isAutoRead, setIsAutoRead] = useState(true); 
  const [selectedVoice, setSelectedVoice] = useState<string>(initialVoice);
  
  // UI States for new controls
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showVoiceMenu, setShowVoiceMenu] = useState(false);

  // Highlighting State
  const [sentences, setSentences] = useState<string[]>([]);
  const [highlightedIndex, setHighlightedIndex] = useState<number>(-1);
  
  // Refs
  const autoReadRef = useRef(isAutoRead);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const speedRef = useRef(playbackSpeed);
  const voiceRef = useRef(selectedVoice);
  const rafRef = useRef<number | null>(null);

  const currentPage = pages[currentPageIndex];
  const t = translations[story.language];

  // Close menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (!(event.target as Element).closest('.control-menu-trigger')) {
        setShowSpeedMenu(false);
        setShowVoiceMenu(false);
      }
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  // Update Refs
  useEffect(() => {
    autoReadRef.current = isAutoRead;
  }, [isAutoRead]);

  useEffect(() => {
    speedRef.current = playbackSpeed;
    if (audioRef.current) {
      applyAudioSettings(audioRef.current, selectedVoice, playbackSpeed);
    }
  }, [playbackSpeed]);

  useEffect(() => {
    voiceRef.current = selectedVoice;
  }, [selectedVoice]);

  // Split text into sentences
  useEffect(() => {
    if (currentPage.text) {
      const chunks = currentPage.text.match(/[^.!?]+[.!?]+["']?\s*|[^.!?]+$/g);
      setSentences(chunks || [currentPage.text]);
      setHighlightedIndex(-1);
    }
  }, [currentPage.text]);

  // Animation Loop for Highlighting
  const updateHighlight = () => {
    const audio = audioRef.current;
    if (!audio || audio.paused || !audio.duration) return;
    
    const currentTime = audio.currentTime;
    const duration = audio.duration;
    const totalChars = currentPage.text.length;
    
    let charCount = 0;
    let activeIndex = -1;
    
    for (let i = 0; i < sentences.length; i++) {
      const segmentLength = sentences[i].length;
      const startRatio = charCount / totalChars;
      const endRatio = (charCount + segmentLength) / totalChars;
      const startTime = startRatio * duration;
      const endTime = endRatio * duration;
      
      if (currentTime >= startTime && currentTime < endTime) {
        activeIndex = i;
        break;
      }
      charCount += segmentLength;
    }
    
    setHighlightedIndex(prev => prev !== activeIndex ? activeIndex : prev);
    rafRef.current = requestAnimationFrame(updateHighlight);
  };

  useEffect(() => {
    if (isPlaying) {
      rafRef.current = requestAnimationFrame(updateHighlight);
    } else {
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
    }
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [isPlaying, sentences, currentPage.text]);

  const updatePage = (index: number, updates: Partial<StoryPage>) => {
    setPages(prev => prev.map((p, i) => i === index ? { ...p, ...updates } : p));
  };

  const ensurePageAssets = async (index: number) => {
    if (index < 0 || index >= pages.length) return;
    const page = pages[index];

    if (!page.imageUrl && !page.isGeneratingImage) {
      updatePage(index, { isGeneratingImage: true });
      generateIllustration(page.imagePrompt)
        .then(imageUrl => updatePage(index, { imageUrl, isGeneratingImage: false }))
        .catch(err => {
          console.error("Image gen failed", err);
          updatePage(index, { isGeneratingImage: false });
        });
    }

    if ((!page.audioUrl || page.audioVoice !== selectedVoice) && !page.isGeneratingAudio) {
      updatePage(index, { isGeneratingAudio: true });
      generatePageAudio(page.text, selectedVoice)
        .then(audioUrl => updatePage(index, { audioUrl, audioVoice: selectedVoice, isGeneratingAudio: false }))
        .catch(err => {
          console.error("Audio gen failed", err);
          updatePage(index, { isGeneratingAudio: false });
        });
    }
  };

  useEffect(() => {
    ensurePageAssets(currentPageIndex);
    if (currentPageIndex < pages.length - 1) {
       ensurePageAssets(currentPageIndex + 1);
    }
    stopAudio();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPageIndex, selectedVoice]);

  useEffect(() => {
    if (currentPage.audioUrl && currentPage.audioVoice === selectedVoice && !isPlaying) {
       if (autoReadRef.current) {
         playAudio();
       }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage.audioUrl, selectedVoice]);

  const applyAudioSettings = (audio: HTMLAudioElement, voice: string, speed: number) => {
    const isChildVoice = voice === 'Puck' || voice === 'Kore';
    if (isChildVoice) {
      const rateMultiplier = 1.15; 
      (audio as any).preservesPitch = false;
      (audio as any).mozPreservesPitch = false;
      (audio as any).webkitPreservesPitch = false;
      audio.playbackRate = speed * rateMultiplier;
    } else {
      (audio as any).preservesPitch = true;
      (audio as any).mozPreservesPitch = true;
      (audio as any).webkitPreservesPitch = true;
      audio.playbackRate = speed;
    }
  };

  const playAudio = () => {
    if (!currentPage.audioUrl) return;
    
    if (!audioRef.current || audioRef.current.src !== currentPage.audioUrl) {
       if (audioRef.current) {
         audioRef.current.pause();
         audioRef.current.src = "";
       }
       const audio = new Audio(currentPage.audioUrl);
       applyAudioSettings(audio, selectedVoice, playbackSpeed);
       
       audio.onended = () => {
         setIsPlaying(false);
         setHighlightedIndex(-1);
         
         const isLastPage = currentPageIndex === pages.length - 1;
         if (isLastPage) {
           setTimeout(() => onOpenChat(), 1500);
         } else if (autoReadRef.current) {
            setTimeout(() => setCurrentPageIndex(p => p + 1), 500);
         }
       };
       audioRef.current = audio;
    } else {
      applyAudioSettings(audioRef.current, selectedVoice, playbackSpeed);
    }

    audioRef.current.play().then(() => setIsPlaying(true)).catch(e => console.error("Playback failed", e));
  };

  const stopAudio = () => {
    if (audioRef.current) audioRef.current.pause();
    setIsPlaying(false);
    setHighlightedIndex(-1);
  };

  const toggleAudio = () => {
    if (isPlaying) stopAudio();
    else playAudio();
  };

  // UI Helper Data
  const voicesConfig = [
    { id: 'Puck', label: t.voices.boy, icon: Smile, color: 'text-blue-500 bg-blue-50' },
    { id: 'Kore', label: t.voices.girl, icon: Smile, color: 'text-pink-500 bg-pink-50' },
    { id: 'Zephyr', label: t.voices.woman, icon: User, color: 'text-purple-500 bg-purple-50' },
    { id: 'Fenrir', label: t.voices.man, icon: UserCheck, color: 'text-emerald-500 bg-emerald-50' },
  ];
  const currentVoiceConfig = voicesConfig.find(v => v.id === selectedVoice) || voicesConfig[0];
  const VoiceIcon = currentVoiceConfig.icon;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 md:p-8">
      
      {/* Header */}
      <div className="w-full max-w-6xl flex justify-between items-center mb-4 md:mb-6">
        <Button variant="ghost" onClick={onExit} className="text-slate-500">
          <Home className="mr-2" size={20} /> {t.back}
        </Button>
        <h2 className="text-xl md:text-2xl font-bold text-amber-800 font-comic hidden md:block truncate max-w-md text-center">{story.title}</h2>
        <div className="w-32"></div>
      </div>

      {/* Main Content */}
      <div className="bg-white w-full max-w-6xl aspect-[3/4] md:aspect-[16/9] rounded-3xl shadow-2xl overflow-hidden border-8 border-amber-100 flex flex-col md:flex-row relative">
        
        {/* Image Section */}
        <div className="w-full md:w-1/2 h-[45%] md:h-full bg-slate-50 relative overflow-hidden flex items-center justify-center border-b-4 md:border-b-0 md:border-r-4 border-amber-100 group">
          {currentPage.imageUrl ? (
             <img 
               src={currentPage.imageUrl} 
               alt={currentPage.imagePrompt}
               className="w-full h-full object-cover animate-fade-in transition-transform duration-[20s] group-hover:scale-110"
             />
          ) : (
            <div className="flex flex-col items-center text-slate-400 animate-pulse">
              <div className="w-16 h-16 bg-slate-200 rounded-full mb-4"></div>
              <p>{t.painting}</p>
            </div>
          )}
          <div className="absolute bottom-4 left-4 md:bottom-6 md:left-6 bg-white/90 backdrop-blur px-3 py-1.5 md:px-4 md:py-2 rounded-full font-bold text-amber-800 shadow-lg z-10 text-sm md:text-base">
            {t.page} {currentPageIndex + 1} {t.of} {pages.length}
          </div>
        </div>

        {/* Text & Controls Section */}
        <div className="w-full md:w-1/2 h-[55%] md:h-full p-6 md:p-10 flex flex-col bg-white bg-[radial-gradient(#f0f9ff_1px,transparent_1px)] [background-size:16px_16px] relative">
          
          {/* Text Area */}
          <div className="flex-1 overflow-y-auto scrollbar-hide mb-20 md:mb-24">
            <p className="text-xl md:text-2xl lg:text-3xl leading-relaxed font-serif text-slate-800 text-center">
              {sentences.map((sentence, i) => (
                <span 
                  key={i} 
                  className={`transition-all duration-300 rounded px-1 decoration-clone ${i === highlightedIndex ? 'bg-amber-200/80 text-amber-900 shadow-sm' : ''}`}
                >
                  {sentence}
                </span>
              ))}
            </p>
          </div>
          
          {/* Voice Loading Indicator */}
          {currentPage.isGeneratingAudio && (
            <div className="absolute top-4 right-4 flex items-center gap-2 bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-xs font-bold animate-pulse shadow-sm">
              <RefreshCw size={12} className="animate-spin" />
              {t.voiceLoading}
            </div>
          )}

          {/* Control Deck - Floating Bottom Bar */}
          <div className="absolute bottom-0 left-0 right-0 p-4 md:p-6 bg-white/90 backdrop-blur-md border-t border-slate-100 flex flex-col gap-4 transition-all">
            
            {/* Settings Bar */}
            <div className="flex items-center justify-between px-1">
               
               <div className="flex items-center gap-3">
                  {/* Voice Selector */}
                  <div className="relative control-menu-trigger">
                    <button 
                      onClick={() => { setShowVoiceMenu(!showVoiceMenu); setShowSpeedMenu(false); }}
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-full border border-slate-200 hover:border-amber-300 hover:bg-amber-50 transition-colors text-sm font-medium text-slate-700 ${showVoiceMenu ? 'ring-2 ring-amber-200 border-transparent' : ''}`}
                    >
                      <div className={`p-1 rounded-full ${currentVoiceConfig.color}`}>
                        <VoiceIcon size={14} />
                      </div>
                      <span className="hidden sm:block">{currentVoiceConfig.label}</span>
                      <ChevronUp size={14} className={`transition-transform ${showVoiceMenu ? '' : 'rotate-180'}`} />
                    </button>
                    
                    {/* Voice Popover */}
                    {showVoiceMenu && (
                      <div className="absolute bottom-full left-0 mb-2 bg-white rounded-2xl shadow-xl border border-slate-100 p-2 w-48 grid grid-cols-1 gap-1 animate-slide-up z-50">
                        <div className="px-2 py-1 text-xs font-bold text-slate-400 uppercase tracking-wider">{t.voice}</div>
                        {voicesConfig.map(v => {
                           const VIcon = v.icon;
                           return (
                             <button
                               key={v.id}
                               onClick={() => { setSelectedVoice(v.id); setShowVoiceMenu(false); }}
                               className={`flex items-center gap-3 px-3 py-2 rounded-xl transition-colors w-full text-left ${selectedVoice === v.id ? 'bg-amber-50 text-amber-800 font-bold' : 'hover:bg-slate-50 text-slate-600'}`}
                             >
                               <div className={`p-1.5 rounded-full ${v.color}`}>
                                 <VIcon size={16} />
                               </div>
                               <span className="text-sm">{v.label}</span>
                               {selectedVoice === v.id && <Check size={14} className="ml-auto text-amber-500" />}
                             </button>
                           );
                        })}
                      </div>
                    )}
                  </div>

                  {/* Speed Selector */}
                  <div className="relative control-menu-trigger">
                     <button 
                        onClick={() => { setShowSpeedMenu(!showSpeedMenu); setShowVoiceMenu(false); }}
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-full border border-slate-200 hover:border-amber-300 hover:bg-amber-50 transition-colors text-sm font-medium text-slate-700 ${showSpeedMenu ? 'ring-2 ring-amber-200 border-transparent' : ''}`}
                     >
                       <Gauge size={16} className="text-slate-400" />
                       <span>{playbackSpeed}x</span>
                     </button>
                     
                     {/* Speed Popover */}
                     {showSpeedMenu && (
                       <div className="absolute bottom-full left-0 mb-2 bg-white rounded-xl shadow-xl border border-slate-100 p-1 w-24 flex flex-col gap-1 animate-slide-up z-50">
                          {[0.75, 1.0, 1.25, 1.5].map(speed => (
                            <button
                              key={speed}
                              onClick={() => { setPlaybackSpeed(speed); setShowSpeedMenu(false); }}
                              className={`px-3 py-2 text-sm rounded-lg transition-colors ${playbackSpeed === speed ? 'bg-amber-50 text-amber-800 font-bold' : 'hover:bg-slate-50 text-slate-600'}`}
                            >
                              {speed}x
                            </button>
                          ))}
                       </div>
                     )}
                  </div>
               </div>

               {/* Auto Turn Toggle */}
               <div 
                 className="flex items-center gap-2 cursor-pointer group"
                 onClick={() => setIsAutoRead(!isAutoRead)}
               >
                  <span className={`text-xs font-bold uppercase tracking-wider transition-colors ${isAutoRead ? 'text-amber-600' : 'text-slate-400'}`}>
                    {t.autoRead}
                  </span>
                  <div className={`w-10 h-6 rounded-full relative transition-colors duration-300 ${isAutoRead ? 'bg-amber-400' : 'bg-slate-200 group-hover:bg-slate-300'}`}>
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform duration-300 ${isAutoRead ? 'left-5' : 'left-1'}`}></div>
                  </div>
               </div>
            </div>

            {/* Navigation Bar */}
            <div className="flex items-center justify-between">
                <Button 
                  variant="ghost" 
                  disabled={currentPageIndex === 0}
                  onClick={() => { stopAudio(); setCurrentPageIndex(p => p - 1); }}
                  className="text-slate-500 hover:text-amber-600"
                >
                  <ArrowLeft size={24} />
                </Button>

                {/* Central Play Button */}
                <button 
                    onClick={toggleAudio}
                    disabled={!currentPage.audioUrl && !currentPage.isGeneratingAudio}
                    className={`
                      w-16 h-16 rounded-full flex items-center justify-center shadow-lg transition-all transform hover:scale-105 active:scale-95
                      ${isPlaying 
                        ? 'bg-white border-2 border-red-100 text-red-500' 
                        : 'bg-gradient-to-br from-amber-400 to-amber-600 text-white shadow-amber-200'
                      }
                      disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none
                    `}
                >
                    {currentPage.isGeneratingAudio ? (
                      <RefreshCw className="animate-spin" size={24} />
                    ) : isPlaying ? (
                      <CirclePause size={32} fill="currentColor" className="opacity-80" />
                    ) : (
                      <PlayCircle size={32} fill="currentColor" className="opacity-80" />
                    )}
                </button>

                <Button 
                  variant="ghost"
                  disabled={currentPageIndex === pages.length - 1}
                  onClick={() => { stopAudio(); setCurrentPageIndex(p => p + 1); }}
                  className="text-slate-500 hover:text-amber-600"
                >
                  <ArrowRight size={24} />
                </Button>
             </div>

          </div>
        </div>
      </div>

      {/* Chat Floating Action Button */}
      <div className="fixed bottom-8 right-8 z-40 group">
        <button 
           onClick={onOpenChat} 
           className="w-14 h-14 rounded-full bg-indigo-600 text-white shadow-xl hover:bg-indigo-700 hover:scale-110 transition-all flex items-center justify-center"
        >
          <MessageCircle size={28} />
        </button>
        <span className="absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-slate-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
          {t.ask}
        </span>
      </div>
    </div>
  );
};
