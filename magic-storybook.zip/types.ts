
export interface StoryPage {
  pageNumber: number;
  text: string;
  imagePrompt: string;
  imageUrl?: string; // Populated after generation
  audioUrl?: string; // Changed from AudioBuffer to string (Blob URL) for HTML5 Audio
  audioVoice?: string; // Track which voice generated this audio
  isGeneratingImage: boolean;
  isGeneratingAudio: boolean;
}

export interface Story {
  id: string;
  title: string;
  pages: StoryPage[];
  language: Language;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export enum AppState {
  LANDING,
  VOICE_SELECTION,
  READING,
}

export type Language = 'en' | 'tr';

export const translations = {
  en: {
    title: "Magic Storybook",
    subtitle: "Tell us an idea, and we'll write a magical story just for you!",
    placeholder: "A dinosaur who loves ballet...",
    create: "Create",
    lucky: "Magical Story",
    generating: "Magic happening...",
    readAloud: "Read Aloud",
    stopReading: "Pause",
    autoRead: "Auto Turn Page",
    speed: "Speed",
    voice: "Narrator",
    voiceLoading: "Loading Voice...",
    back: "Back to Library",
    next: "Next",
    prev: "Prev",
    ask: "Ask the story!",
    chatTitle: "Story Spirit",
    chatPlaceholder: "Ask a question...",
    page: "Page",
    of: "of",
    painting: "Painting the picture...",
    features: ["AI Generated Stories", "Magical Voices", "Beautiful Pictures"],
    error: "Oops! The magic ink ran dry. Please try again.",
    languageName: "English",
    selectVoiceTitle: "Who should read the story?",
    selectVoiceSubtitle: "Pick a storyteller to begin your adventure!",
    voices: {
      boy: "Boy",
      girl: "Girl",
      woman: "Woman",
      man: "Man"
    },
    creative: {
      adjectives: ["A brave", "A clumsy", "A tiny", "A giant", "A sleepy", "A curious", "A magical", "A colorful", "A shy", "A speedy"],
      characters: ["dinosaur", "robot", "kitten", "wizard", "astronaut", "penguin", "dragon", "unicorn", "puppy", "turtle"],
      actions: ["who loves to dance", "who creates a rainbow", "who finds a treasure", "who builds a rocket", "who bakes cookies", "who learns to fly", "who saves the forest", "who makes a new friend"],
      places: ["on the moon", "in a candy forest", "under the deep blue sea", "in a flying castle", "at a monster party", "inside a volcano", "in a secret garden", "on a pirate ship"]
    }
  },
  tr: {
    title: "Sihirli Hikaye Kitabı",
    subtitle: "Bir fikir söyle, senin için sihirli bir hikaye yazalım!",
    placeholder: "Bale yapan bir dinozor...",
    create: "Oluştur",
    lucky: "Sihirli Hikaye",
    generating: "Sihir yapılıyor...",
    readAloud: "Sesli Oku",
    stopReading: "Duraklat",
    autoRead: "Otomatik Çevir",
    speed: "Hız",
    voice: "Anlatıcı",
    voiceLoading: "Ses Yükleniyor...",
    back: "Kitaplığa Dön",
    next: "İleri",
    prev: "Geri",
    ask: "Hikayeye sor!",
    chatTitle: "Hikaye Ruhu",
    chatPlaceholder: "Bir soru sor...",
    page: "Sayfa",
    of: "/",
    painting: "Resim çiziliyor...",
    features: ["Yapay Zeka Hikayeler", "Sihirli Sesler", "Güzel Resimler"],
    error: "Hay aksi! Sihirli mürekkep bitti. Lütfen tekrar dene.",
    languageName: "Türkçe",
    selectVoiceTitle: "Hikayeyi kim okusun?",
    selectVoiceSubtitle: "Maceraya başlamak için bir anlatıcı seç!",
    voices: {
      boy: "Erkek Çocuk",
      girl: "Kız Çocuk",
      woman: "Kadın",
      man: "Erkek"
    },
    creative: {
      adjectives: ["Cesur bir", "Şaşkın bir", "Minik bir", "Dev bir", "Uykucu bir", "Meraklı bir", "Sihirli bir", "Renkli bir", "Utangaç bir", "Hızlı bir"],
      characters: ["dinozor", "robot", "yavru kedi", "büyücü", "astronot", "penguen", "ejderha", "tek boynuzlu at", "köpek yavrusu", "kaplumbağa"],
      actions: ["dans etmeyi seven", "gökkuşağı yapan", "hazine bulan", "roket inşa eden", "kurabiye pişiren", "uçmayı öğrenen", "ormanı kurtaran", "yeni bir arkadaş edinen"],
      places: ["ayda", "şeker ormanında", "derin mavi denizde", "uçan bir şatoda", "canavar partisinde", "yanardağın içinde", "gizli bir bahçede", "korsan gemisinde"]
    }
  }
};
