
import React, { useState } from 'react';
import { StoryCreator } from './components/StoryCreator';
import { BookReader } from './components/BookReader';
import { ChatInterface } from './components/ChatInterface';
import { VoiceSelector } from './components/VoiceSelector';
import { generateStoryStructure } from './services/geminiService';
import { Story, AppState, Language, translations } from './types';
import { getAudioContext } from './services/audioUtils';

export default function App() {
  const [appState, setAppState] = useState<AppState>(AppState.LANDING);
  const [currentStory, setCurrentStory] = useState<Story | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [language, setLanguage] = useState<Language>('en');
  const [selectedVoice, setSelectedVoice] = useState<string>('Puck');

  const handleGenerateStory = async (prompt: string) => {
    setIsGenerating(true);
    // Initialize audio context on user interaction
    getAudioContext().resume(); 
    
    try {
      const { title, pages } = await generateStoryStructure(prompt, language);
      
      const newStory: Story = {
        id: Date.now().toString(),
        title,
        language,
        pages: pages.map(p => ({
          ...p,
          isGeneratingImage: false,
          isGeneratingAudio: false
        }))
      };

      setCurrentStory(newStory);
      setAppState(AppState.VOICE_SELECTION); // Go to voice selection first
    } catch (error) {
      console.error("Failed to generate story", error);
      alert(translations[language].error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleVoiceSelected = (voice: string) => {
    setSelectedVoice(voice);
    setAppState(AppState.READING);
  };

  const handleExitStory = () => {
    setAppState(AppState.LANDING);
    setCurrentStory(null);
    setIsChatOpen(false);
  };

  return (
    <div className="min-h-screen bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] bg-fixed">
      
      {appState === AppState.LANDING && (
        <StoryCreator 
          onGenerate={handleGenerateStory} 
          isGenerating={isGenerating} 
          language={language}
          setLanguage={setLanguage}
        />
      )}

      {appState === AppState.VOICE_SELECTION && (
        <VoiceSelector 
          language={language} 
          onSelect={handleVoiceSelected} 
        />
      )}

      {appState === AppState.READING && currentStory && (
        <>
          <BookReader 
            story={currentStory} 
            initialVoice={selectedVoice}
            onExit={handleExitStory}
            onOpenChat={() => setIsChatOpen(true)}
          />
          <ChatInterface 
            isOpen={isChatOpen} 
            onClose={() => setIsChatOpen(false)}
            storyContext={currentStory.title + ": " + currentStory.pages.map(p => p.text).join(" ")}
            language={language}
          />
        </>
      )}
    </div>
  );
}
