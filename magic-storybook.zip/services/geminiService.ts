
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { StoryPage, Language } from "../types";
import { base64ToArrayBuffer, pcmToWav, getAudioContext } from "./audioUtils";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const TEXT_MODEL = 'gemini-3-pro-preview';
const IMAGE_MODEL = 'imagen-4.0-generate-001';
const FALLBACK_IMAGE_MODEL = 'gemini-2.5-flash-image';
const TTS_MODEL = 'gemini-2.5-flash-preview-tts';

export const generateStoryStructure = async (prompt: string, language: Language): Promise<{ title: string; pages: Omit<StoryPage, 'isGeneratingImage' | 'isGeneratingAudio'>[] }> => {
  const langInstruction = language === 'tr' ? "Write the story in Turkish." : "Write the story in English.";
  
  const response = await ai.models.generateContent({
    model: TEXT_MODEL,
    contents: `Write a children's story based on this idea: "${prompt}". 
    ${langInstruction}
    The story should be suitable for kids aged 4-8. 
    Split the story into 4-6 pages. 
    For each page, provide the story text and a detailed prompt for an image generator to create a colorful, kid-friendly illustration matching the text.
    The image prompt should always be in English, regardless of the story language.
    Return the result as JSON.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING, description: "The title of the story" },
          pages: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                pageNumber: { type: Type.INTEGER },
                text: { type: Type.STRING, description: "The text content of this page of the story." },
                imagePrompt: { type: Type.STRING, description: "A descriptive prompt for an image generator to visualize this page (Always in English)." },
              },
              required: ["pageNumber", "text", "imagePrompt"],
            },
          },
        },
        required: ["title", "pages"],
      },
    },
  });

  if (!response.text) {
    throw new Error("No text returned from Gemini");
  }

  return JSON.parse(response.text);
};

export const generateIllustration = async (prompt: string): Promise<string> => {
  const enrichedPrompt = `${prompt}. Children's book illustration style, vibrant colors, cute, high quality, detailed, digital art.`;

  try {
    // Attempt 1: High Quality Imagen Model
    const response = await ai.models.generateImages({
      model: IMAGE_MODEL,
      prompt: enrichedPrompt,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/jpeg',
        aspectRatio: '1:1',
      },
    });

    const base64ImageBytes = response.generatedImages?.[0]?.image?.imageBytes;
    if (!base64ImageBytes) throw new Error("No image generated from Imagen");
    
    return `data:image/jpeg;base64,${base64ImageBytes}`;

  } catch (error) {
    console.warn("Imagen model failed (likely quota), switching to fallback model:", error);

    try {
      // Attempt 2: Flash Image Model (Faster/Different Quota)
      const response = await ai.models.generateContent({
        model: FALLBACK_IMAGE_MODEL,
        contents: {
          parts: [{ text: enrichedPrompt }]
        },
        config: {
          responseModalities: [Modality.IMAGE],
        }
      });

      const part = response.candidates?.[0]?.content?.parts?.[0];
      if (part?.inlineData?.data) {
         return `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
      }
      throw new Error("No image generated from Flash");

    } catch (fallbackError) {
      console.error("All image generation models failed:", fallbackError);
      // Attempt 3: Last Resort Placeholder
      return `https://picsum.photos/800/800?random=${Math.random()}`;
    }
  }
};

export const generatePageAudio = async (text: string, voiceName: string = 'Puck'): Promise<string> => {
  const response = await ai.models.generateContent({
    model: TTS_MODEL,
    contents: [{ parts: [{ text: text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: voiceName },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) {
    throw new Error("No audio data returned");
  }

  // Decode base64 to raw PCM
  const arrayBuffer = base64ToArrayBuffer(base64Audio);
  const int16Array = new Int16Array(arrayBuffer);

  // Convert to WAV blob
  const wavBlob = pcmToWav(int16Array, 24000);
  
  // Create Object URL for HTML Audio element
  return URL.createObjectURL(wavBlob);
};

export const sendChatMessage = async (history: {role: 'user' | 'model', text: string}[], newMessage: string, language: Language): Promise<string> => {
  const langInstruction = language === 'tr' ? "Answer in Turkish." : "Answer in English.";
  
  const chat = ai.chats.create({
    model: TEXT_MODEL,
    history: history.map(h => ({
      role: h.role,
      parts: [{ text: h.text }]
    })),
    config: {
        systemInstruction: `You are a magical book character. ${langInstruction} Answer the child's questions about the story enthusiastically and simply. Keep answers short (under 50 words).`
    }
  });

  const result = await chat.sendMessage({ message: newMessage });
  return result.text || "I didn't catch that, could you say it again?";
};
